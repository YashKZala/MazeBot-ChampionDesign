# MazeBot Champion Design

Complete hardware, wiring, and firmware template for a Robofest-winning maze solver robot.