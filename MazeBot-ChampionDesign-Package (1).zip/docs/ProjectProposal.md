# Project Proposal

## Objective
Design a maze-solving robot for Robofest.